﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using System.Linq;




namespace Bitmap
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
           
        }

        public void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string adresse = Adresse.Text;
            
            //Process.Start(adresse);
        }
        
        
        private void Button_Click(object sender, RoutedEventArgs e)//Rotation
        {

            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);

            Image.Rotation90();

            Process.Start("a.bmp");

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)//Nuances de gris 1
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Nuancedegris();
            Process.Start("a.bmp");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)//nuances de gris 2
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Nuancedegris2();
            Process.Start("a.bmp");
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)//sepia
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.sepia();
            Process.Start("a.bmp");
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)//noir et blanc
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.NoiretBlanc();
            Process.Start("a.bmp");
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.InversionDesCouleurs();
            Process.Start("a.bmp");
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Agrandir();
            Process.Start("a.bmp");
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Retrecir();
            Process.Start("a.bmp");
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Multiple();
            Process.Start("a.bmp");
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Contraste();
            Process.Start("a.bmp");
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            
            Process.Start("a.bmp");
        }

        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Mcontraste();
            Process.Start("a.bmp");
        }

        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Mflou();
            Process.Start("a.bmp");
        }

        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.MRepoussage();
            Process.Start("a.bmp");
        }

        private void Button_Click_14(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Accentuation();
            Process.Start("a.bmp");
        }

        private void Button_Click_15(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.MRbords();
            Process.Start("a.bmp");
        }

        private void Button_Click_16(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.MDbords();
            Process.Start("a.bmp");
        }

        private void Button_Click_17(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.MRelief();
            Process.Start("a.bmp");
        }

        private void Button_Click_18(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.LissageParConvolution();
            Process.Start("a.bmp");
        }

        private void Button_Click_19(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Filtregaussien();
            Process.Start("a.bmp");
        }

        private void Button_Click_20(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.MBinomial();
            Process.Start("a.bmp");
        }

        private void Button_Click_21(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.MDbordsSobel1();
            Image.MDbordsSobel2();
            Process.Start("a.bmp");
        }

        private void Button_Click_22(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.MDbordsRobert1();
            Image.MDbordsRobert2();
            Image.MDbordsRobert3();
            Process.Start("a.bmp");
        }

        private void Button_Click_23(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Histogramme();
            Process.Start("a.bmp");
        }

        private void Button_Click_24(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Nuancedegris2();
            Image.MDbordsRobert1();
            Image.MDbordsRobert2();
            Image.MDbordsRobert3();
            Process.Start("a.bmp");
        }

        private void Button_Click_25(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Nuancedegris2();
            Image.MDbordsPrewitt1();
            Image.MDbordsPrewitt2();
            Process.Start("a.bmp");
        }

        private void Button_Click_26(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Nuancedegris2();
            Image.MDbordsSobel1();
            Image.MDbordsSobel2();
            Process.Start("a.bmp");
        }

        private void Button_Click_27(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Nuancedegris2();
            Image.LissageParConvolution();
            Image.MDbordsSobel1();
            Image.MDbordsSobel2();
            Process.Start("a.bmp");
        }

        private void Button_Click_28(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Nuancedegris2();
            Image.LissageParConvolution();
            Image.MDbordsPrewitt1();
            Image.MDbordsPrewitt2();
            Process.Start("a.bmp");
        }

        private void Button_Click_29(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Nuancedegris2();
            Image.LissageParConvolution();
            Image.MDbordsRobert1();
            Image.MDbordsRobert2();
            Image.MDbordsRobert3();
            Process.Start("a.bmp");
        }

        private void Button_Click_30(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.FormeGéométrique();
            Process.Start("a.bmp");
        }

        private void Button_Click_31(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.ImageAléatoire();
            Process.Start("a.bmp");
        }

        private void Button_Click_32(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.FloudeMouvement();
            Process.Start("a.bmp");
        }

        private void Button_Click_33(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Agrandir();
            Image.LissageParConvolution();
            Image.Net();
            Process.Start("a.bmp");
        }

        private void Button_Click_34(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Net();
            Process.Start("a.bmp");
        }

        private void Button_Click_35(object sender, RoutedEventArgs e)
        {
            string adress = Adresse.Text;
            MyImage Image = new MyImage(adress);
            Image.MDbordsPrewitt1();
            Image.MDbordsPrewitt2();
            Process.Start("a.bmp");
        }

        private void Button_Click_36(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Rouge();
            Process.Start("a.bmp");
        }

        private void Button_Click_37(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Vert();
            Process.Start("a.bmp");
        }

        private void Button_Click_38(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Bleu();
            Process.Start("a.bmp");
        }

        private void Button_Click_39(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);
            Image.Coloriser();
            Process.Start("a.bmp");
        }

        private void Button_Click_40(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            
            Process.Start(adresse);
        }

        private void Button_Click_41(object sender, RoutedEventArgs e)
        {
            string adresse1 = AdresseH.Text;
            MyImage Image = new MyImage(adresse1);

            string adresse2 = AdresseD.Text;
            MyImage ImageD = new MyImage(adresse2);

            string adresse3 = AdresseR.Text;
            MyImage ImageR = new MyImage(adresse3);

            Image.HDR(ImageD,ImageR);

            Process.Start("a.bmp");
        }

        private void Button_Click_43(object sender, RoutedEventArgs e)
        {
            string adresse = Adresse.Text;
            MyImage Image = new MyImage(adresse);

            Image.Cercle();
            Process.Start("a.bmp");
        }

       
        
    }
}
