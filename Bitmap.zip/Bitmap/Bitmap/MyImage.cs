﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using System.Linq;

namespace Bitmap
{
    class MyImage
    {//Attributs de ma classe
        public int Largeur;
        public int Hauteur;
        private int Taille;
        private int Octectdebut;
        int[,] Filtre;//de taille 3*3
        int[,] Filtre2;//celui ci sera de taille 5*5
        byte[] Header;//Premier header
        byte[] HeaderInfo;//header avec les infos, le deuxieme header
        byte[] image;//corps de l'image
        byte[] ImageEtInfo;//tout le fichier
        RVB[,] Image;
       
      

        private int Modulo4 = 0;

        string fichier;

        public string Fichier
        {
            get
            {
                return fichier;
            }
        }
        public int octectdebut
        {
            get
            {
                return Octectdebut;
            }
        }
        public MyImage(string Fichier)
        //Constructeur de la classe 
        {

            this.ImageEtInfo = File.ReadAllBytes(Fichier);//Tableau
            this.Header = new byte[14]; //Taille (Fixe) du tableau pour le premier header 
            int OctectDebut = ImageEtInfo[10];//récuperation octect départ
            byte[] HeaderInfo = new byte[OctectDebut - 14];//Taille dépend octect départ

            Largeur = 0;
            Hauteur = 0;
            Taille = 0;

            fichier = Fichier;

            while (!((Largeur + Modulo4) * 3 % 4 == 0))//Vérification si multiple de 4
                Modulo4++;//

            Largeur += Modulo4;//compteur pour savoir combien de fois on à rajouté des 0

            Taille = (Largeur * Hauteur) * 3;//Taille du fichier

            image = new byte[Largeur * Hauteur * 3];//Tableau qui contiendra tout le corps de l'image

            for (int i = 0; i < image.Length; i++) //Remplissage du tableau
                image[i] = ImageEtInfo[i + OctectDebut];

            Filtre = new int[3, 3];// matrice qui va contenir le filtre pour nos filtres 3*3
            Filtre2 = new int[5, 5];//ici 5*5
            for (int i = 0; i < 14; i++)//Remplissage du Header
                Header[i] = ImageEtInfo[i];

            for (int i = 0; i < OctectDebut - 14; i++)//Remplisage du deuxieme Header
            {
                HeaderInfo[i] = ImageEtInfo[i + 14];
            }

            //Récupération des donnés en binaire
            byte[] largeurBinaire = { HeaderInfo[4], HeaderInfo[5], HeaderInfo[6], HeaderInfo[7] };
            byte[] hauteurBinaire = { HeaderInfo[8], HeaderInfo[9], HeaderInfo[10], HeaderInfo[11] };
            byte[] OctectdebutBinaire = { Header[10], Header[11], Header[12], Header[13] };

            //Nous devons maintenant convertir les données binaires en INTEGER

            Largeur = BitConverter.ToInt32(largeurBinaire, 0);
            Hauteur = BitConverter.ToInt32(hauteurBinaire, 0);
            Octectdebut = BitConverter.ToInt32(OctectdebutBinaire, 0);

            Image = new RVB[Hauteur, Largeur];

            for (int i = 0, k = 54; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++, k++)
                {
                    Image[i, j] = new RVB(ImageEtInfo[k], ImageEtInfo[k + 1], ImageEtInfo[k + 2]);
                    k = k + 2;
                }
            }

            


        }
        public void From_Image_To_File(string file)
        {
            byte[] taille = Convertir_Int_To_Endian(Largeur * Hauteur * 3 + 54);
            byte[] ImageEtInfo2 = new byte[Hauteur * Largeur * 3 + 54];//création nouveau tab pour contenir donnés
            for (int i = 0; i < 2; i++)
            {
                ImageEtInfo2[i] = ImageEtInfo[i];
            }
            for (int i = 2, k = 0; i < 6; i++, k++)
            {
                ImageEtInfo2[i] = taille[k];
            }
            for (int i = 6; i < 18; i++)
            {
                ImageEtInfo2[i] = ImageEtInfo[i];
            }
            for (int i = 26; i < 54; i++)
            {
                ImageEtInfo2[i] = ImageEtInfo[i];
            }
            byte[] largeur = Convertir_Int_To_Endian(Largeur);
            for (int i = 18, k = 0; i < 22; i++, k++)
            {
                ImageEtInfo2[i] = largeur[k];
            }
            byte[] hauteur = Convertir_Int_To_Endian(Hauteur);
            for (int i = 22, k = 0; i < 26; i++, k++)
            {
                ImageEtInfo2[i] = hauteur[k];
            }
            for (int i = 0, k = 54; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++, k++)
                {
                    ImageEtInfo2[k] = Convert.ToByte(Image[i, j].Bleu);
                    k++;
                    ImageEtInfo2[k] = Convert.ToByte(Image[i, j].Vert);
                    k++;
                    ImageEtInfo2[k] = Convert.ToByte(Image[i, j].Rouge);
                }
            }
            File.WriteAllBytes(file, ImageEtInfo2);//creation du fichier

        }
        public int Convertir_Endian_To_Int(byte[] tab, int index, int Taille)
        {
            int ValeurTampon = 0;
            byte[] LitlleEndianVersInteger = new byte[Taille]; //Transformer le LittleEndian en Entier
            for (int i = 0; i < Taille; i++)
            {
                LitlleEndianVersInteger[i] = tab[Taille - 1 - i];
                //On parcourt le tableau à l'endroit pour mettre dans notre nouveau tableau les valeurs dans l'autre sens
            }
            for (int i = 0; i < Taille; i++)
            {
                ValeurTampon += LitlleEndianVersInteger[i] * Convert.ToInt32(Math.Pow(16, Taille - 1 - i));
            }
            Console.WriteLine(ValeurTampon);
            return ValeurTampon;
        }
        /// <summary>
        /// Rotation
        /// </summary>
        public void Rotation90()
        {
            RVB[,] Image2 = new RVB[Largeur, Hauteur];
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[j, i] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Largeur; i++)
            {
                for (int j = 0; j < Hauteur; j++)
                {
                    Image2[i, j].Rouge = Image[j, i].Rouge;
                    Image2[i, j].Bleu = Image[j, i].Bleu;
                    Image2[i, j].Vert = Image[j, i].Vert;
                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);
            Image = Image2;
            From_Image_To_File("a.bmp");

        }
        /// <summary>
        /// Noir et blanc avec moyenne des 3 couleurs
        /// </summary>
        public void Nuancedegris()
        {
            var a = 0;


            RVB[,] Image2 = new RVB[Hauteur, Largeur];
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {

                    a = (Image[i, j].Rouge + Image[i, j].Bleu + Image[i, j].Vert) / 3;
                    Image2[i, j].Rouge = a;
                    Image2[i, j].Bleu = a;
                    Image2[i, j].Vert = a;
                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }
        /// <summary>
        /// Nuance de gris permettant d'obtenir de meilleurs coefficients
        /// </summary>
        public void Nuancedegris2()
        {

            RVB[,] Image2 = new RVB[Hauteur, Largeur];
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {


                    Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000; ;
                    Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000; ;
                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }
        /// <summary>
        /// Permet de réaliser une inversion des couleurs
        /// </summary>
        public void InversionDesCouleurs()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j].Rouge = 255 - Image[i, j].Rouge;
                    Image2[i, j].Bleu = 255 - Image[i, j].Bleu;
                    Image2[i, j].Vert = 255 - Image[i, j].Vert;
                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }
        /// <summary>
        /// transforme une photo en sépia
        /// </summary>
        public void sepia()
        {

            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {


                    Image2[i, j].Rouge = (Image[i, j].Rouge * 393 + Image[i, j].Bleu * 189 + Image[i, j].Vert * 769) / 1000;
                    Image2[i, j].Vert = (Image[i, j].Rouge * 349 + Image[i, j].Bleu * 168 + Image[i, j].Vert * 686) / 1000;
                    Image2[i, j].Bleu = (Image[i, j].Rouge * 272 + Image[i, j].Bleu * 131 + Image[i, j].Vert * 534) / 1000;

                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }
        /// <summary>
        /// Noir et blanc 
        /// </summary>
        public void NoiretBlanc()
        {
            var a = 0;
            var b = 0;
            var c = 0;


            RVB[,] Image2 = new RVB[Hauteur, Largeur];
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {

                    a = (Image[i, j].Rouge + Image[i, j].Bleu + Image[i, j].Vert) / 4;

                    if (a <= 120)
                    {
                        Image2[i, j].Rouge = 0;
                        Image2[i, j].Bleu = 0;
                        Image2[i, j].Vert = 0;
                    }
                    else
                    {
                        Image2[i, j].Rouge = 255;
                        Image2[i, j].Bleu = 255;
                        Image2[i, j].Vert = 255;
                    }




                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }
        /// <summary>
        /// permet d'augmenter le contraste
        /// </summary>
        public void Contraste()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    if (Image[i, j].Rouge <= 170)
                    {
                        Image2[i, j].Rouge = Image[i, j].Rouge - 9;
                    }
                    if (Image[i, j].Rouge >= 171)
                    {
                        Image2[i, j].Rouge = Image[i, j].Rouge + 9;
                    }

                    if (Image[i, j].Bleu <= 170)
                    {
                        Image2[i, j].Bleu = Image[i, j].Bleu - 9;
                    }
                    if (Image[i, j].Bleu >= 171)
                    {
                        Image2[i, j].Bleu = Image[i, j].Bleu + 9;
                    }

                    if (Image[i, j].Vert <= 170)
                    {
                        Image2[i, j].Vert = Image[i, j].Vert - 9;
                    }
                    if (Image[i, j].Vert >= 171)
                    {
                        Image2[i, j].Vert = Image[i, j].Vert + 9;
                    }

                    if (Image2[i, j].Rouge <= 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Bleu <= 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Vert <= 0)
                    {
                        Image2[i, j].Vert = 0;
                    }


                    if (Image2[i, j].Rouge >= 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }
                    if (Image2[i, j].Bleu >= 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }
                    if (Image2[i, j].Vert >= 255)
                    {
                        Image2[i, j].Vert = 255;
                    }


                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }
        /// <summary>
        /// Agrandir Image par 2
        /// </summary>
        public void Agrandir()
        {

            RVB[,] Image2 = new RVB[2 * Hauteur, 2 * Largeur];

            for (int i = 0; i < 2 * Hauteur; i++)
            {
                for (int j = 0; j < 2 * Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }

            for (int i = 0; i < Hauteur * 2; i++)
            {
                for (int j = 0; j < Largeur * 2; j++)
                {


                    Image2[i, j].Rouge = Image[i / 2, j / 2].Rouge;

                    Image2[i, j].Bleu = Image[i / 2, j / 2].Bleu;

                    Image2[i, j].Vert = Image[i / 2, j / 2].Vert;


                }

            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);
            Image = Image2;


            From_Image_To_File("a.bmp");


        }
        /// <summary>
        /// Agrandir Image par des puissance de 2
        /// </summary>
        public void Multiple()
        {
            //Console.WriteLine("quelle facteur voulez vous ? ");
            int n = 3;

            for (int K = 0; K < n; K++)
            {

                RVB[,] Image2 = new RVB[2 * Hauteur, 2 * Largeur];

                for (int i = 0; i < 2 * Hauteur; i++)
                {
                    for (int j = 0; j < 2 * Largeur; j++)
                    {
                        Image2[i, j] = new RVB(0, 0, 0);
                    }
                }

                for (int i = Hauteur; i < Hauteur * 2; i++)
                {
                    for (int j = Largeur; j < Largeur * 2; j++)
                    {
                        Image2[i, j].Rouge = Image[i - Hauteur, j - Largeur].Rouge;

                        Image2[i, j].Bleu = Image[i - Hauteur, j - Largeur].Bleu;

                        Image2[i, j].Vert = Image[i - Hauteur, j - Largeur].Vert;
                    }

                }
                for (int i = 0; i < Hauteur; i++)
                {
                    for (int j = Largeur; j < Largeur * 2; j++)
                    {
                        Image2[i, j].Rouge = Image[i, j - Largeur].Rouge;

                        Image2[i, j].Bleu = Image[i, j - Largeur].Bleu;

                        Image2[i, j].Vert = Image[i, j - Largeur].Vert;
                    }
                }

                for (int i = Hauteur; i < Hauteur * 2; i++)
                {
                    for (int j = 0; j < Largeur; j++)
                    {
                        Image2[i, j].Rouge = Image[i - Hauteur, j].Rouge;

                        Image2[i, j].Bleu = Image[i - Hauteur, j].Bleu;

                        Image2[i, j].Vert = Image[i - Hauteur, j].Vert;
                    }

                }
                for (int i = 0; i < Hauteur; i++)
                {
                    for (int j = 0; j < Largeur; j++)
                    {
                        Image2[i, j].Rouge = Image[i, j].Rouge;

                        Image2[i, j].Bleu = Image[i, j].Bleu;

                        Image2[i, j].Vert = Image[i, j].Vert;
                    }

                }

                Largeur = Image2.GetLength(1);
                Hauteur = Image2.GetLength(0);
                Image = Image2;

                From_Image_To_File("a.bmp");

            }





        }
        /// <summary>
        /// Rétrécir l'image par 2
        /// </summary>
        public void Retrecir()
        {

            RVB[,] Image2 = new RVB[Hauteur / 2, Largeur / 2];

            for (int i = 0; i < Hauteur / 2; i++)
            {
                for (int j = 0; j < Largeur / 2; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }

            for (int i = 0; i < Hauteur / 2; i++)
            {
                for (int j = 0; j < Largeur / 2; j++)
                {


                    Image2[i, j].Rouge = Image[i * 2, j * 2].Rouge;

                    Image2[i, j].Bleu = Image[i * 2, j * 2].Bleu;

                    Image2[i, j].Vert = Image[i * 2, j * 2].Vert;


                }

            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);
            Image = Image2;


            From_Image_To_File("a.bmp");


        }
        /// <summary>
        /// Matrice de contraste
        /// </summary>
        public void Mcontraste()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 0, -1, 0 },{ -1, 5, -1}, { 0, -1, 0}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Matrice flou
        /// </summary>
        public void Mflou()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 1, 1, 1 },{ 1, 1, 1}, { 1, 1, 1}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }

                    Image2[i, j].Rouge = Image2[i, j].Rouge / 9;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 9;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 9;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Matrice Renforcement Bord
        /// </summary>
        public void MRbords()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 0, 0, 0 },{ -1, 1, 0}, { 0, 0, 0}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// rend l'image plus nette
        /// </summary>
        public void Accentuation()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 0, -5, 0 },{ -5, 30, -5}, { 0, -5, 0}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 10;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 10;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 10;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Détection bord (laplacien 4cx)
        /// </summary>
        public void MDbords()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 0, 1, 0 },{ 1, -4, 1}, { 0, 1, 0}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Détection des bords précis a l'aide du Filtre de Prewitt
        /// </summary>
        public void MDbordsPrewitt1()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { -1, -1, -1 },{ 0, 0, 0}, { 1, 1, 1}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Détection des bords précis a l'aide du Filtre de Prewitt
        /// </summary>
        public void MDbordsPrewitt2()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { -1, 0, 1 },{ -1, 0, +1}, { -1, 0, +1}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// le filtre de Sobel semble être le filtre à tout faire il faut lancer les 3 filtres dans le main
        /// </summary>
        public void MDbordsRobert1()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { -1, -2, -1 },{ 0, 0, 0}, { 1, 2, 1}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        public void MDbordsRobert2()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { -1, 0, 1 },{ -2, 0, 2}, { -1, 0, 1}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        public void MDbordsRobert3()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 0, 1, 2 },{ -1, 0, 1}, { -2, -1, 0}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Matrice Repoussage
        /// </summary>
        public void MRepoussage()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { -2, -1, 0 },{ -1, 1, 1}, { 0, 1, 2}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// le filtre gaussien est utile pour a reduire le bruit c'est un filtre passe bas
        /// </summary>
        public void Filtregaussien()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 1, 2, 1 },{ 2, 4, 2}, { 1, 2, 1}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 16;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 16;

                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 16;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Matrice filtre binomial c'est un filtre passe bas
        /// </summary>
        public void MBinomial()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 1, 4, 6,4,1 },{4,16,24,16,4}, {6,24,36,24,6},{4,16,24,16,4},{1,4,6,4,1}
            };

            for (int i = 3; i < Hauteur - 5; i++)
            {
                for (int j = 3; j < Largeur - 5; j++)
                {
                    for (int k = 0; k < 5; k++)
                    {
                        for (int l = 0; l < 5; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 256;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 256;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 256;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        
        /// <summary>
        /// Détection des bords a l'aide du Filtre de Sobel
        /// </summary>
        public void MDbordsSobel1()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { -1, 0, 1 },{ -2, 0, 2}, { -1, 0, 1}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        public void MDbordsSobel2()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { -1, -1, -1 },{ 0, 0, 0}, { 1, 2, 1}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Filtre pour obtenir un relief
        /// </summary>
        public void MRelief()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { -2, -1, 0 },{ -1, 0, 1}, {0, 1, 2}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// forme geometrique pour afficher un quadrillage pour verifier qu'une photo est droite
        /// </summary>
        public void FormeGéométrique()
        {


            //Console.WriteLine("Quelle Largeur voulez vous ");
            int Largeur2 = 400;
            int Hauteur2 = Largeur2;


            RVB[,] Image2 = new RVB[Hauteur2, Largeur2];

            for (int i = 0; i < Hauteur2; i++)
            {
                for (int j = 0; j < Largeur2; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }

            for (int i = Hauteur2 / 3, k = Largeur2 / 3; i < 2 * (Hauteur2 / 3); i++, k++)//diag du carré gauche a droite
            {
                Random randNum = new Random();
                int a = randNum.Next(255);
                Random randNum2 = new Random();
                int b = randNum.Next(255);
                Random randNum3 = new Random();
                int c = randNum.Next(255);

                Image2[i, k].Rouge = a;
                Image2[i, k].Bleu = b;
                Image2[i, k].Vert = c;
            }
            for (int i = Hauteur2 / 3, k = 2 * Largeur2 / 3; k > Largeur2 / 3; i++, k--)
            {
                Random randNum = new Random();
                int a = randNum.Next(255);
                Random randNum2 = new Random();
                int b = randNum.Next(255);
                Random randNum3 = new Random();
                int c = randNum.Next(255);

                Image2[i, k].Rouge = a;
                Image2[i, k].Bleu = b;
                Image2[i, k].Vert = c;
            }
            //petit carré
            for (int i = Largeur2 / 3, k = Hauteur2 / 3; k < Hauteur2 - Hauteur2 / 3; k++)
            {
                Image2[i, k].Rouge = 0;
                Image2[i, k].Bleu = 255;
                Image2[i, k].Vert = 255;
            }
            for (int i = Largeur2 / 3, k = Hauteur2 / 3; i < Largeur2 - Largeur2 / 3; i++)
            {
                Image2[i, k].Rouge = 255;
                Image2[i, k].Bleu = 0;
                Image2[i, k].Vert = 255;
            }
            for (int i = Largeur2 / 3, k = 2 * Hauteur2 / 3; i < Largeur2 - Largeur2 / 3; i++)
            {
                Image2[i, k].Rouge = 255;
                Image2[i, k].Bleu = 255;
                Image2[i, k].Vert = 0;
            }
            for (int i = 2 * Largeur2 / 3, k = Hauteur2 / 3; k < Hauteur2 - Hauteur2 / 3; k++)
            {
                Image2[i, k].Rouge = 120;
                Image2[i, k].Bleu = 255;
                Image2[i, k].Vert = 50;
            }



            Largeur = Largeur2;
            Hauteur = Hauteur2;
            Image = Image2;
            From_Image_To_File("a.bmp");
        }
        /// <summary>
        ///génére une image aléatoire avec une taille définie 
        /// </summary>
        public void ImageAléatoire()
        {

            //Console.WriteLine("Quelle Largeur voulez vous ");
            int Largeur2 = 400;
            //Console.WriteLine("Quelle Hauteur voulez vous ");
            int Hauteur2 = 400;


            RVB[,] Image2 = new RVB[Hauteur2, Largeur2];

            for (int i = 0; i < Hauteur2; i++)
            {
                for (int j = 0; j < Largeur2; j++)
                {

                    Random randNum = new Random();
                    int a = randNum.Next(255);
                    Random randNum2 = new Random();
                    int b = randNum.Next(255);
                    Random randNum3 = new Random();
                    int c = randNum.Next(255);

                    Image2[i, j] = new RVB(a, b, c);

                }
            }
            Largeur = Largeur2;
            Hauteur = Hauteur2;
            Image = Image2;
            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// affiche l'histogramme avec rvb et fait apparaitre jaune et cyan
        /// </summary>
        public void Histogramme()
        {
            int NombreRépétitionsR = 0;
            int NombreRépétitionsB = 0;
            int NombreRépétitionsV = 0;

            int HauteurMax = 0;

            for (int i = 0; i < 256; i++)
            {
                NombreRépétitionsR = 0;
                NombreRépétitionsV = 0;
                NombreRépétitionsB = 0;

                for (int j = 0; j < Hauteur; j++)
                {
                    for (int l = 0; l < Largeur; l++)
                    {
                        if (Image[j, l].Rouge == i)
                        {
                            NombreRépétitionsR += 1;
                            if (NombreRépétitionsR >= HauteurMax)
                            {
                                HauteurMax = NombreRépétitionsR;
                            }
                        }

                    }
                }
            }

            RVB[,] Image2 = new RVB[HauteurMax*3, 256];

            for (int i = 0; i < HauteurMax*3; i++)
            {
                for (int j = 0; j < 256; j++)
                {
                    Image2[i, j] = new RVB(255, 255, 255);
                }
            }

            for (int i = 0; i < 256; i++)
            {
                NombreRépétitionsR = 0;
                NombreRépétitionsV = 0;
                NombreRépétitionsB = 0;

                for (int j = 0; j < Hauteur; j++)
                {
                    for (int l = 0; l < Largeur; l++)
                    {
                        if (Image[j, l].Rouge == i)
                        {
                            Image2[NombreRépétitionsR, i].Rouge = 255;
                            Image2[NombreRépétitionsR, i].Bleu = 0;
                            Image2[NombreRépétitionsR, i].Vert = 0;
                            NombreRépétitionsR += 1;
                        }

                        if (Image[j, l].Bleu == i)
                        {
                            if (Image[j, l].Bleu >= Image[j, l].Rouge)
                            {
                                Image2[NombreRépétitionsB, i].Bleu = 255;
                                Image2[NombreRépétitionsB, i].Rouge = 0;

                                NombreRépétitionsB += 1;
                            }

                        }
                        if (Image[j, l].Vert == i)
                        {
                            if (Image[j, l].Vert >= Image[j, l].Rouge && Image[j, l].Vert >= Image[j, l].Bleu)
                            {
                                Image2[NombreRépétitionsV, i].Bleu = 0;
                                Image2[NombreRépétitionsV, i].Rouge = 0;
                                Image2[NombreRépétitionsV, i].Vert = 255;
                                NombreRépétitionsV += 1;
                            }

                        }
                        if (Image[j, l].Bleu == i)
                        {
                            if (Image[j, l].Bleu < Image[j, l].Vert)
                            {
                                Image2[NombreRépétitionsB, i].Bleu = 0;
                                NombreRépétitionsB += 1;
                            }

                        }


                    }
                }
            }

           

            Image = Image2;
            Hauteur = Image2.GetLength(0);
            Largeur = Image2.GetLength(1);
            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Le lissage par convolution consiste à appliquer un filtre particulier de dimensions 5*5 qui permet d'atténuer les contours.
        /// </summary>
        public void LissageParConvolution()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                {4, 18, 19,18,4 },{18,80,132,80,18}, {29,132,238,132,29},{18,80,132,80,18},{4, 18, 19,18,4 }
            };

            for (int i = 3; i < Hauteur - 5; i++)
            {
                for (int j = 3; j < Largeur - 5; j++)
                {
                    for (int k = 0; k < 5; k++)
                    {
                        for (int l = 0; l < 5; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1344;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1344;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1344;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Matrice filtre binomial c'est un filtre passe bas
        /// </summary>
        public void FloudeMouvement()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 2, 0, 0,0,0 },{0,2,0,0,0}, {0,0,2,0,0},{0,0,0,2,0},{0,0,0,0,2}
            };

            for (int i = 3; i < Hauteur - 5; i++)
            {
                for (int j = 3; j < Largeur - 5; j++)
                {
                    for (int k = 0; k < 5; k++)
                    {
                        for (int l = 0; l < 5; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 10;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 10;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 10;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        public void Net()
        {
            RVB[,] Image2 = new RVB[Hauteur, Largeur];

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            Filtre = new int[,]
            {
                { 0, -1, 0},{ -1, 5, -1}, { 0, -1, 0}
            };

            for (int i = 1; i < Hauteur - 3; i++)
            {
                for (int j = 1; j < Largeur - 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            Image2[i, j].Rouge += Image[i + k, j + l].Rouge * Filtre[k, l];
                            Image2[i, j].Bleu += Image[i + k, j + l].Bleu * Filtre[k, l];
                            Image2[i, j].Vert += Image[i + k, j + l].Vert * Filtre[k, l]; ;
                        }
                    }
                    Image2[i, j].Rouge = Image2[i, j].Rouge / 1;

                    if (Image2[i, j].Rouge < 0)
                    {
                        Image2[i, j].Rouge = 0;
                    }
                    if (Image2[i, j].Rouge > 255)
                    {
                        Image2[i, j].Rouge = 255;
                    }

                    Image2[i, j].Bleu = Image2[i, j].Bleu / 1;
                    if (Image2[i, j].Bleu < 0)
                    {
                        Image2[i, j].Bleu = 0;
                    }
                    if (Image2[i, j].Bleu > 255)
                    {
                        Image2[i, j].Bleu = 255;
                    }

                    Image2[i, j].Vert = Image2[i, j].Vert / 1;
                    if (Image2[i, j].Vert < 0)
                    {
                        Image2[i, j].Vert = 0;
                    }
                    if (Image2[i, j].Vert > 255)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            From_Image_To_File("a.bmp");
        }
        public void Rouge()
        {
            var a = 0;
            var b = 0;
            var c = 0;


            RVB[,] Image2 = new RVB[Hauteur, Largeur];
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {

                    a = Image[i, j].Rouge;
                    b = Image[i, j].Vert;
                    c = Image[i, j].Bleu;

                    if (a <= 170)
                    {
                        Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    }
                    else
                    {

                        Image2[i, j].Rouge = Image[i, j].Rouge;
                        Image2[i, j].Bleu = Image[i, j].Bleu;
                        Image2[i, j].Vert = Image[i, j].Vert;
                    }

                    if (a >= 170 && c >= 100)
                    {
                        Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    }
                    if (a >= 170 && b >= 100)
                    {
                        Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    }


                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }
        public void Vert()
        {
            var a = 0;
            var b = 0;
            var c = 0;


            RVB[,] Image2 = new RVB[Hauteur, Largeur];
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {

                    a = Image[i, j].Rouge;
                    b = Image[i, j].Vert;
                    c = Image[i, j].Bleu;

                    if (b <= 120)
                    {
                        Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    }
                    else
                    {

                        Image2[i, j].Rouge = Image[i, j].Rouge;
                        Image2[i, j].Bleu = Image[i, j].Bleu;
                        Image2[i, j].Vert = Image[i, j].Vert;
                    }

                    if (b >= 120 && c >= 145)
                    {
                        Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    }
                    if (b >= 120 && a >= 150)
                    {
                        Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    }


                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }
        public void Bleu()
        {
            var a = 0;
            var b = 0;
            var c = 0;


            RVB[,] Image2 = new RVB[Hauteur, Largeur];
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {

                    a = Image[i, j].Rouge;
                    b = Image[i, j].Vert;
                    c = Image[i, j].Bleu;

                    if (c <= 140)
                    {
                        Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    }
                    else
                    {

                        Image2[i, j].Rouge = Image[i, j].Rouge;
                        Image2[i, j].Bleu = Image[i, j].Bleu;
                        Image2[i, j].Vert = Image[i, j].Vert;
                    }

                    if (c >= 140 && a >= 150)
                    {
                        Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    }
                    if (c >= 140 && b >= 150)
                    {
                        Image2[i, j].Rouge = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Bleu = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                        Image2[i, j].Vert = (Image[i, j].Rouge * 299 + Image[i, j].Bleu * 587 + Image[i, j].Vert * 114) / 1000;
                    }


                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }
        public void Cercle()
        {
            int Largeur2 = 500;
            int Hauteur2 = Largeur2;


            RVB[,] Image2 = new RVB[Hauteur2, Largeur2];

            for (int i = 0; i < Hauteur2; i++)
            {
                for (int j = 0; j < Largeur2; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }


            int R = 1500;
            int Ci = 200;
            int Cj = 203;


            for (int i = 0; i<Hauteur2; i++)
            {
               for (int j=0; j< Largeur2;j++)
                {
                    if ((i - Ci)*(i - Ci)  + (j - Cj)*(j-Cj)  <= R )
                    {
                        Image2[i, j].Rouge = 255;
                    }
                }
            }

            Cj = 247;
            for (int i = 0; i < Hauteur2; i++)
            {
                for (int j = 0; j < Largeur2; j++)
                {
                    if ((i - Ci) * (i - Ci) + (j - Cj) * (j - Cj) <= R)
                    {
                        Image2[i, j].Bleu = 255;
                    }
                }
            }

             Ci = 240;
             Cj = 225;
            for (int i = 0; i < Hauteur2; i++)
            {
                for (int j = 0; j < Largeur2; j++)
                {
                    if ((i - Ci) * (i - Ci) + (j - Cj) * (j - Cj) <= R)
                    {
                        Image2[i, j].Vert = 255;
                    }
                }
            }

            Image = Image2;
            Hauteur = Image2.GetLength(0);
            Largeur = Image2.GetLength(1);
            From_Image_To_File("a.bmp");
        }
        
        public void HDR(MyImage ImageD,MyImage ImageR)
        {
           
            RVB[,] ImageD2 = ImageD.Image;
            RVB[,] ImageR2 = ImageR.Image;

            RVB[,] Image2 = new RVB[Hauteur, Largeur];
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }

            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j].Rouge = (Image[i, j].Rouge + 3*ImageD2[i,j].Rouge + 4*ImageR2[i,j].Rouge)/8;
                    Image2[i, j].Bleu = (Image[i, j].Bleu +3* ImageD2[i, j].Bleu + 4*ImageR2[i, j].Bleu) /8; ;
                    Image2[i, j].Vert = (Image[i, j].Vert + 3*ImageD2[i, j].Vert + 4*ImageR2[i, j].Vert) /8; ;
                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");
        }
        /// <summary>
        /// Filtre pour coloriser
        /// </summary>
        public void Coloriser()
        {

            RVB[,] Image2 = new RVB[Hauteur, Largeur];
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {
                    Image2[i, j] = new RVB(0, 0, 0);
                }
            }
            for (int i = 0; i < Hauteur; i++)
            {
                for (int j = 0; j < Largeur; j++)
                {

                    Image2[i, j].Rouge = Image[i, j].Rouge * (1000 / 299) / 3;
                    Image2[i, j].Bleu = Image[i, j].Bleu * (1000 / 587) / 3;
                    Image2[i, j].Vert = Image[i, j].Vert * (1000 / 299) / 3;
                }
            }
            Largeur = Image2.GetLength(1);
            Hauteur = Image2.GetLength(0);

            Image = Image2;

            From_Image_To_File("a.bmp");


        }

        public byte[] Convertir_Int_To_Endian(int valeur)
        {
            byte[] tab = BitConverter.GetBytes(valeur);
            return tab;
        }
    }  
}
