﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bitmap
{

    class RVB //Classe qui va contenir les octects pour les couleurs RVB( Rouge, Vert, Bleu)
    {
        int rouge;
        int vert;
        int bleu;

        public int Rouge
        {
            get
            {
                return rouge;
            }

            set
            {
                rouge = value;
            }
        }
        public int Vert
        {
            get
            {
                return vert;
            }

            set
            {
                vert = value;
            }
        }
        public int Bleu
        {
            get
            {
                return bleu;
            }

            set
            {
                bleu = value;
            }
        }
        public RVB(int b, int v, int r)//Tableau pour contenir les 3 couleurs donc de taille 3, ce tableau va nous permettre de manipuler le tableau pour par exemple renverser l'image ou la detection de contour
        {
                bleu = b;
                vert = v;
                rouge = r;
                   
        }
    }
    

}
